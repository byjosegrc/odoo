package com.example.sqllite14_11_22.models

data class Usuarios(
    var id: Int?,
    var nombre: String,
    var email: String
): java.io.Serializable
